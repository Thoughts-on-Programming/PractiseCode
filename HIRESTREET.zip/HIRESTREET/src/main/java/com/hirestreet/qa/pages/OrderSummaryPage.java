package com.hirestreet.qa.pages;

import com.hirestreet.qa.base.TestBase;

public class OrderSummaryPage extends TestBase{

}
