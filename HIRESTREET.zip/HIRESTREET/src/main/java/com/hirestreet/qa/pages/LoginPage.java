package com.hirestreet.qa.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.hirestreet.qa.base.TestBase;
import com.hirestreet.qa.util.TestUtil;

public class LoginPage extends TestBase{
	
	@FindBy(xpath = "//input[@name='login']")
	WebElement email;
	@FindBy(xpath = "//input[@id='userSigninPassword']")
	WebElement password;
	@FindBy(xpath = "(//span[normalize-space()='Sign In'])[1]")
	WebElement signin;
	@FindBy(xpath = "//a[@class='profile-icon']")
	WebElement profileicon;
	@FindBy(xpath = "//button[@class = 'needsclick klaviyo-close-form kl-private-reset-css-Xuajs1']")
	WebElement popup;
	@FindBy(xpath = "//a[@class = 'btn-accept-all  btn btn-primary']")
	WebElement accept;
	
	public LoginPage()
	{
		PageFactory.initElements(driver, this);
	}
	
	public String validateLognPageTitle()
	{
		
		return driver.getTitle();
		
	}
	
	public boolean validateProfileIconImage()
	{
		
		return profileicon.isDisplayed();
	}
	
	public AccountPage login(String em, String pw)
	
	{
		if(popup.isDisplayed())
		{
			popup.click();
		}
		
		
		profileicon.click();
		email.sendKeys(em);
		password.sendKeys(pw);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		signin.click();
	
		/*Actions actions = new Actions(driver);
		actions.doubleClick(signin).perform();*/
		return new AccountPage();	
	
	}
	
}
