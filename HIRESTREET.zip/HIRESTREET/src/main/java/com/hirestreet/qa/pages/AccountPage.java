package com.hirestreet.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.hirestreet.qa.base.TestBase;

public class AccountPage extends TestBase{
	
	@FindBy(xpath = "//span[@class='numberCircle']")
	WebElement basketIcon;;
	
	public AccountPage()
	{
		PageFactory.initElements(driver, this);
	}
	
	public OrderPage clickOnBasketLink()
	{
		basketIcon.click();	
		return new OrderPage();
	}

}
