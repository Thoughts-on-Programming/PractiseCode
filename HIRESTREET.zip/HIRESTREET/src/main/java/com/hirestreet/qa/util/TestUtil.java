package com.hirestreet.qa.util;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import com.hirestreet.qa.base.TestBase;

public class TestUtil extends TestBase{
	public static long PAGE_LOAD_TIMEOUT  = 40;
	public static long IMPLICIT_WAIT  = 30;
	
	public void screenShot()
	{
		TakesScreenshot takeScreenshot =  (TakesScreenshot)driver;
		File sourceFile = takeScreenshot.getScreenshotAs(OutputType.FILE);
		
		File destFile = new File ("C:\\Users\\admin\\Documents\\Pooja\\ProjectWorkspace\\HIRESTREET\\ScreenShot\\"+"screenshotshot_"+this.getClass().getName()+"_"+System.currentTimeMillis()+".jpg");
		try {
			FileUtils.copyFile(sourceFile, destFile);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Saved");		
	}
	
	

}
