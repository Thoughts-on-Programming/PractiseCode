package com.hirestreet.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.hirestreet.qa.base.TestBase;

public class OrderPage extends TestBase {
	//@FindBy(xpath = "//input[@name='login']")
	//WebElement email;
	
	public OrderPage()
	{
		PageFactory.initElements(driver, this);
	}
	
	public String verifyTitle()
	{
		return driver.getTitle();
	}
	
	
}
