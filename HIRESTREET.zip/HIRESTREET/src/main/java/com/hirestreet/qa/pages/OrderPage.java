package com.hirestreet.qa.pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.hirestreet.qa.base.TestBase;

public class OrderPage extends TestBase {
	//@FindBy(xpath = "//input[@name='login']")
	//WebElement email;
	
	@FindBy(xpath = "//div[@id='discount-code-btn']")
	WebElement discountfield;
	
	@FindBy(xpath = "//input[@id='DiscountCode']")
	WebElement discounttextfield;
	
	@FindBy(xpath = "//button[@id='applyDiscount']")
	WebElement applybutton;

	@FindBy(xpath = "//a[@class='w-100 mt-3 btn btn-primary checkout-button']")
	WebElement checkoutbutton;
	
	@FindBy(xpath = "//small[@id='discount-error']")
	WebElement discounterror;
	
	@FindBy(xpath = "(//div[@class='label'])[6]")
	WebElement discountcalculation;
	
	@FindBy(xpath = "//i[@class='remove-discount icon-cross icon-right']")
	WebElement discountremove;
	
	
	
//basket-prices-row basket-discount-row
	
	public OrderPage()
	{
		PageFactory.initElements(driver, this);
	}
	
	public String verifyTitle()
	{
		return driver.getTitle();
	}
	
	public void clickOnDiscountField()
	{
		discountfield.click();
	}
	
public String verifyInvalidDiscountCode(String invalid) {
		
	Actions a = new Actions(driver);
	//scroll down a page
	a.sendKeys(Keys.PAGE_DOWN).build().perform();
	try {
		Thread.sleep(1000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		discounttextfield.click();
		discounttextfield.sendKeys(invalid);
		applybutton.click();
		
		String error_msg = discounterror.getText();
		return error_msg;
		
	}

public String verifyvalidDiscountCode(String valid) {
	
	discounttextfield.clear();
	discounttextfield.click();
	discounttextfield.sendKeys(valid);
	applybutton.click();
	String discountcheck = discountcalculation.getText();
	return discountcheck;
}

public OrderSummaryPage checkout() {
	checkoutbutton.click();
	return new OrderSummaryPage();
	
}

public void clearingtheAppliedDiscount() {
	driver.navigate().back();
	discountremove.click();
	
}

	
}
