package com.hirestreet.qa.testcases;

import org.testng.annotations.*;

import com.hirestreet.qa.base.TestBase;
import com.hirestreet.qa.pages.HomePage;
import com.hirestreet.qa.pages.LoginPage;
import com.hirestreet.qa.pages.AccountPage;

import junit.framework.Assert;

public class LoginPageTest extends TestBase {
	LoginPage loginPage;
	AccountPage  accountPage;
	
	public LoginPageTest()
	{
		super();
	}

	@BeforeClass
	public void setUp()
	{
		initialization();
		loginPage  = new LoginPage();		
	}
	
	@Test(priority = 1)
	public void loginPageTitleTest()
	{
		String title = loginPage.validateLognPageTitle();
		Assert.assertEquals(title, "Hirestreet | Rent Dresses For All Occasions");
		
	}
	
	@Test(priority = 2)
	public void profileIconTest()
	{
		boolean flag = loginPage.validateProfileIconImage();
		Assert.assertTrue(flag);
	}
	
	@Test(priority = 3)
	public void loginPageTest()
	{
		loginPage.ToU();
		accountPage = loginPage.login(prop.getProperty("email"), prop.getProperty("password"));
		
	}
	
	@AfterClass
	public void tearDown()
	{
		driver.quit();
	}
	
}
