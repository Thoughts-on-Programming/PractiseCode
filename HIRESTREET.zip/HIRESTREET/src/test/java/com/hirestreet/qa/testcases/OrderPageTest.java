package com.hirestreet.qa.testcases;

import org.junit.Assert;
import org.testng.annotations.*;
import com.hirestreet.qa.base.TestBase;
import com.hirestreet.qa.pages.AccountPage;
import com.hirestreet.qa.pages.LoginPage;
import com.hirestreet.qa.pages.OrderPage;

public class OrderPageTest extends TestBase{
	LoginPage loginPage;
	AccountPage accountPage;
	OrderPage orderPage;
	
	public OrderPageTest(){
		super();
	}
	
	@BeforeClass
	public void setUp()
	{
		initialization();
		loginPage  = new LoginPage();
		//orderPage = new OrderPage();
		accountPage =loginPage.login(prop.getProperty("email"), prop.getProperty("password"));
		orderPage = accountPage.clickOnBasketLink();
	}
	
	@Test
	public void VerifyOrderTitleTest()
	{
		String orderTitle = orderPage.verifyTitle();
		System.out.println(orderTitle);
		Assert.assertEquals(orderTitle, "Your Hirestreet shopping bag | Hirestreet");
	}
	
	@AfterClass
	public void tearDown()
	{
		driver.quit();
	}
	
}
