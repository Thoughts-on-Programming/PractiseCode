package com.hirestreet.qa.testcases;

import org.junit.Assert;
import org.testng.annotations.*;
import com.hirestreet.qa.base.TestBase;
import com.hirestreet.qa.pages.AccountPage;
import com.hirestreet.qa.pages.LoginPage;
import com.hirestreet.qa.pages.OrderPage;
import com.hirestreet.qa.pages.OrderSummaryPage;

public class OrderPageTest extends TestBase{
	LoginPage loginPage;
	AccountPage accountPage;
	OrderPage orderPage;
	OrderSummaryPage ordersumpage;
	
	public OrderPageTest(){
		super();
	}
	
	@BeforeClass
	public void setUp()
	{
		initialization();
		loginPage  = new LoginPage();
		//orderPage = new OrderPage();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		loginPage.acceptpopup();
		loginPage.ToU();
		accountPage =loginPage.login(prop.getProperty("email"), prop.getProperty("password"));
		
		orderPage = accountPage.clickOnBasketLink();
	}
	
	@Test(priority = 1)
	public void VerifyOrderTitleTest()
	{
		String orderTitle = orderPage.verifyTitle();
		Assert.assertEquals(orderTitle, "Your Hirestreet shopping bag | Hirestreet");
	}
	
	@Test(priority = 2)
	public void ClickonDiscountField()
	{
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		orderPage.clickOnDiscountField();
		
	}
	

	@Test(priority = 3)
	public void VerifyInvalidDiscountCode(){
		String msg = orderPage.verifyInvalidDiscountCode(prop.getProperty("invaliddiscountcode"));
		System.out.print(msg);
		System.out.print("messageee");
		Assert.assertEquals(msg, "* Oops. Invalid discount code \"Test123\"");
	}
	
	@Test(priority = 4)
	public void VerifyvalidDiscountCodeandcheckout(){
		String discCheck = orderPage.verifyvalidDiscountCode(prop.getProperty("validdiscountcode"));
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Assert.assertEquals(discCheck, "RAF25:");
		ordersumpage = orderPage.checkout();
		//orderPage.clearingtheAppliedDiscount();
	}
	
	
	@AfterClass
	public void tearDown()
	{
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//driver.quit();
	}
	
}
