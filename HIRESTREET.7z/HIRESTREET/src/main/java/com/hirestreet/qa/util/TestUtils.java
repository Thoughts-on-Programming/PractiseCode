package com.hirestreet.qa.util;

public class TestUtils {
	
	public static long pageLoadTimeOut = 30;
	
	public static long implecitWait = 30;
	
	

}
